import requests
import json
import logging
import sys
import qrcode
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Suprimindo o aviso de requisição HTTPS não verificada
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Configurando o logging
logging.basicConfig(level=logging.INFO)

# Carregar dados de configuração a partir do arquivo config.json
with open('config.json', 'r') as config_file:
    config = json.load(config_file)

token_url = config["token_url"]
client_id = config["client_id"]
client_secret = config["client_secret"]
crt = config["crt"]
key = config["key"]

# Headers e payload para a requisição de token
headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
}

payload = {
    'grant_type': 'client_credentials',
    'client_id': client_id,
    'client_secret': client_secret,
}

def get_access_token():
    response = requests.post(
        token_url+"oauth/token",
        headers=headers,
        data=payload,
        cert=(crt, key),
        verify=False  # Desativa a verificação SSL
    )

    if response.status_code in [200, 201]:
        token_data = response.json()
        return token_data.get('access_token')
    else:
        logging.error("Failed to obtain token: %s %s", response.status_code, response.text)
        raise Exception("Failed to obtain token")

def process_request(txid, nome, identificacao, valor_original, endereco, data_vencimento, descricao, access_token):
    if len(identificacao) == 11:
        tipo_identificacao = "cpf"
    elif len(identificacao) == 14:
        tipo_identificacao = "cnpj"
    else:
        return {"error": "Identificação inválida"}

    payload_boleto = {
        "calendario": {
            "dataDeVencimento": data_vencimento,
            "validadeAposVencimento": 30
        },
        "devedor": {
            "logradouro": endereco,
            "cidade": "bRASILIA",
            "uf": "PB",
            "cep": "58920000",
            tipo_identificacao: identificacao,
            "nome": nome
        },
        "recebedor": {
            "logradouro": "Rua Castor da Paz",
            "cidade": "Campina Grande",
            "uf": "PB",
            "cep": "58423440",
            "cnpj": "17088110000500",
            "nome": "PROVEDOR X"
        },
        "valor": {
            "original": "{:.2f}".format(valor_original),
            "multa": {
                "modalidade": "2",
                "valorPerc": "2.00"
            },
            "juros": {
                "modalidade": "2",
                "valorPerc": "0.36"
            }
        },
        "chave": "258915d9-abaf-49a8-a6c5-24708f18470a",
        "solicitacaoPagador": descricao
    }

    headers_boleto = {
        'Authorization': 'Bearer {}'.format(access_token),
        'Content-Type': 'application/json'
    }

    boleto_url = token_url+"cobv/{}".format(txid)

    response_boleto = requests.put(
        boleto_url,
        headers=headers_boleto,
        data=json.dumps(payload_boleto),
        cert=(crt, key),
        verify=False  # Desativa a verificação SSL
    )

    if response_boleto.status_code in [200, 201]:
        boleto_data = response_boleto.json()
        pix_copia_e_cola = boleto_data.get('pixCopiaECola')

        img = qrcode.make(pix_copia_e_cola)
        img_path = "img/{}.png".format(txid)
        
        # Verificando se o diretório existe, se não, cria
        import os
        os.makedirs(os.path.dirname(img_path), exist_ok=True)
        
        # Corrigindo a abertura do arquivo para modo binário de escrita
        with open(img_path, "wb") as f:
            img.save(f)

        return {
            "txid": txid,
            "qrcode": img_path,
            "pixCopiaECola": pix_copia_e_cola,
            "status": boleto_data.get('status')
        }
    else:
        logging.error("Falha ao gerar o boleto: %s %s", response_boleto.status_code, response_boleto.text)
        return {"error": "Falha ao gerar o boleto", "details": response_boleto.text}

def main(requests_data):
    try:
        access_token = get_access_token()
    except Exception as e:
        logging.error("Error obtaining access token: %s", e)
        print(json.dumps({"error": "Erro ao obter o token de acesso"}))
        sys.exit(1)

    results = []
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(process_request, txid, nome, identificacao, valor_original, endereco, data_vencimento, descricao, access_token) for txid, nome, identificacao, valor_original, endereco, data_vencimento, descricao in requests_data]
        for future in as_completed(futures):
            results.append(future.result())

    print(json.dumps(results, indent=4))

if __name__ == "__main__":
    # Exemplo de uso: python script.py '[["txid1", "nome1", "identificacao1", 100.0, "endereco1", "2024-12-31", "descricao1"], ["txid2", "nome2", "identificacao2", 200.0, "endereco2", "2024-12-31", "descricao2"]]'
    if len(sys.argv) != 2:
        print(json.dumps({"error": "Informações insuficientes fornecidas"}))
        sys.exit(1)

    requests_data = json.loads(sys.argv[1])
    main(requests_data)

