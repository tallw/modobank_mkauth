<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(to right, #6a11cb, #2575fc);
            font-family: Arial, sans-serif;
            overflow: hidden;
        }

        .login-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
        }

        .login-container h2 {
            margin-bottom: 20px;
            color: #333;
        }

        .login-container input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #6a11cb;
            color: white;
            font-size: 16px;
            cursor: pointer;
            box-sizing: border-box;
        }

        .login-container button:hover {
            background-color: #2575fc;
        }

        @media (max-width: 768px) {
            .login-container {
                padding: 15px;
                max-width: 90%; /* Ocupa 90% da largura disponível */
            }

            .login-container h2 {
                font-size: 22px;
            }

            .login-container input[type="text"], .login-container button {
                padding: 12px;
                font-size: 14px;
            }
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 10px;
                max-width: 90%; /* Ocupa 90% da largura disponível */
            }

            .login-container h2 {
                font-size: 20px;
            }

            .login-container input[type="text"], .login-container button {
                padding: 10px;
                font-size: 12px;
            }
        }
    </style>
    <script>
        function formatCPF(event) {
            const input = event.target.querySelector('input[name="cpf"]');
            const formattedCPF = input.value.replace(/\D/g, '');
            input.value = formattedCPF;
        }

        // Ajustar a altura do corpo para garantir a centralização em dispositivos móveis
        function ajustarAlturaCorpo() {
            document.body.style.height = window.innerHeight + 'px';
        }

        window.addEventListener('resize', ajustarAlturaCorpo);
        window.addEventListener('load', ajustarAlturaCorpo);
    </script>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="check_cpf.php" method="POST" onsubmit="formatCPF(event)">
            <input type="text" name="cpf" placeholder="CPF" required>
            <button type="submit">Entrar</button>
        </form>
    </div>
</body>
</html>

