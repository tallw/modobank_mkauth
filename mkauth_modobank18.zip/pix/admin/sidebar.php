<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="inicio.php" class="brand-link">
        <span class="brand-text font-weight-light">Sistema de Boletos</span>
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="info">
                <a href="#" class="d-block">Admin</a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="inicio.php" class="nav-link">
                        <i class="nav-icon fas fa-home"></i>
                        <p>Home</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="criar_boleto.php" class="nav-link">
                        <i class="nav-icon fas fa-file-invoice"></i>
                        <p>Criar Boleto</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="configurar_api.php" class="nav-link">
                        <i class="nav-icon fas fa-cogs"></i>
                        <p>Configurar API</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>

