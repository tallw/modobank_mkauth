<footer class="main-footer">
    <strong>&copy; 2024 <a href="#">SEU PROVEDOR</a>.</strong>
    Todos os direitos reservados.
</footer>

