<?php
include 'db.php';

$login = $_GET['login'];
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 5;
$offset = ($page - 1) * $limit;

// Buscar informações do cliente
$sql = "SELECT * FROM sis_cliente WHERE login = '$login'";
$result = $conn->query($sql);
$cliente = $result->fetch_assoc();

// Buscar total de faturas para calcular o total de páginas
$total_sql = "SELECT COUNT(*) FROM sis_lanc l
              INNER JOIN pix_info2 p ON l.id = p.id_lanc
              WHERE l.login = '$login'
              AND l.status IN ('aberto', 'vencido')
              AND l.deltitulo = 0
              AND l.nossonum IS NULL";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_row();
$total = $total_row[0];
$total_pages = ceil($total / $limit);

// Ajustar a página se for maior que o total de páginas
if ($page > $total_pages && $total_pages > 0) {
    $page = $total_pages;
    $offset = ($page - 1) * $limit;
}

// Buscar faturas abertas e vencidas com informações de pix_info
$aberto_sql = "SELECT l.*, p.pix_copia_cola, p.qrcode
               FROM sis_lanc l
               INNER JOIN pix_info2 p ON l.id = p.id_lanc
               WHERE l.login = '$login'
               AND l.status IN ('aberto', 'vencido')
               AND l.deltitulo = 0
               AND l.nossonum IS NULL
               ORDER BY l.status ASC
               LIMIT $limit OFFSET $offset";
$aberto_result = $conn->query($aberto_sql);
$faturas_aberto = array();

while ($fatura = $aberto_result->fetch_assoc()) {
    $faturas_aberto[] = $fatura;
}

function formatarData($data) {
    $date = new DateTime($data);
    return $date->format('Y-m-d');
}

function obterStatus($status) {
    return $status == 'aberto' ? 'Aberto' : ($status == 'vencido' ? 'Vencido' : 'Pago');
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Faturas</title>
    <link rel="stylesheet" href="https://adminlte.io/themes/v3/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="https://adminlte.io/themes/v3/dist/css/adminlte.min.css">
    <script src="https://adminlte.io/themes/v3/plugins/jquery/jquery.min.js"></script>
    <script src="https://adminlte.io/themes/v3/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="https://adminlte.io/themes/v3/dist/js/adminlte.min.js"></script>
    <style>
        .content-wrapper {
            margin-left: 0;
            padding: 2rem;
        }
        .toast {
            position: fixed;
            bottom: 1rem;
            right: 1rem;
            z-index: 1080;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <div class="content-wrapper">
            <section class="content">
                <div class="container-fluid">
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Faturas de <?php echo htmlspecialchars($cliente['nome'], ENT_QUOTES, 'UTF-8'); ?></h3>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group" id="faturas-list">
                                        <?php foreach ($faturas_aberto as $fatura) { ?>
                                            <li class="list-group-item d-flex justify-content-between align-items-center" id="fatura-<?php echo $fatura['id']; ?>">
                                                <div>
                                                    <h5 class="mb-1">Valor: R$<?php echo htmlspecialchars($fatura['valor'], ENT_QUOTES, 'UTF-8'); ?></h5>
                                                    <small>Vencimento: <?php echo formatarData($fatura['datavenc']); ?></small><br>
                                                    <small class="status badge badge-<?php echo $fatura['status'] == 'aberto' ? 'warning' : ($fatura['status'] == 'vencido' ? 'danger' : 'success'); ?>">
                                                        <?php echo obterStatus($fatura['status']); ?>
                                                    </small>
                                                </div>
                                                <button class="btn btn-primary btn-sm pagar-btn" data-id="<?php echo $fatura['id']; ?>" data-pix="<?php echo htmlspecialchars($fatura['pix_copia_cola'], ENT_QUOTES, 'UTF-8'); ?>" data-qrcode="<?php echo htmlspecialchars($fatura['qrcode'], ENT_QUOTES, 'UTF-8'); ?>">Pagar</button>
                                            </li>
                                        <?php } ?>
                                    </ul>
                                </div>
                                <div class="card-footer">
                                    <nav>
                                        <ul class="pagination justify-content-center mb-0">
                                            <?php if ($total_pages > 1) { ?>
                                                <?php if ($page > 1) { ?>
                                                    <li class="page-item">
                                                        <a class="page-link" href="?login=<?php echo htmlspecialchars($login, ENT_QUOTES, 'UTF-8'); ?>&page=<?php echo $page - 1; ?>" aria-label="Previous">
                                                            <span aria-hidden="true">&laquo;</span>
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                                <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
                                                    <?php if ($i == $page || ($i >= $page - 2 && $i <= $page + 2) || $i == 1 || $i == $total_pages) { ?>
                                                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                                            <a class="page-link" href="?login=<?php echo htmlspecialchars($login, ENT_QUOTES, 'UTF-8'); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                                        </li>
                                                        <?php if ($i == 1 && $page > 4) { ?>
                                                            <li class="page-item disabled"><span class="page-link">...</span></li>
                                                        <?php } ?>
                                                        <?php if ($i == $total_pages && $page < $total_pages - 3) { ?>
                                                            <li class="page-item disabled"><span class="page-link">...</span></li>
                                                        <?php } ?>
                                                    <?php } ?>
                                                <?php } ?>
                                                <?php if ($page < $total_pages) { ?>
                                                    <li class="page-item">
                                                        <a class="page-link" href="?login=<?php echo htmlspecialchars($login, ENT_QUOTES, 'UTF-8'); ?>&page=<?php echo $page + 1; ?>" aria-label="Next">
                                                            <span aria-hidden="true">&raquo;</span>
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                            <?php } ?>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="pagamento-modal" tabindex="-1" role="dialog" aria-labelledby="pagamento-modal-label" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Detalhes do Pagamento</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" id="pagamento-detalhes"></div>
                </div>
            </div>
        </div>

        <!-- Toast -->
        <div class="toast" id="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-body">
                Pix Copiado!
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Função de copiar Pix
            function copiarPix() {
                var pixCopiaCola = document.getElementById('pix-copia-e-cola').value;
                navigator.clipboard.writeText(pixCopiaCola).then(function() {
                    var toast = new bootstrap.Toast(document.getElementById('toast'));
                    toast.show();
                }).catch(function(error) {
                    console.error('Erro ao copiar o Pix:', error);
                });
            }

            // Adicionar eventos de clique nos botões de pagamento
            document.querySelectorAll('.pagar-btn').forEach(function(button) {
                button.addEventListener('click', function() {
                    var pixCopiaCola = this.getAttribute('data-pix');
                    var qrcode = this.getAttribute('data-qrcode');
                    var detalhes = document.getElementById('pagamento-detalhes');
                    detalhes.innerHTML = `
                        <p>Pix Copia e Cola:</p>
                        <textarea class="form-control" id="pix-copia-e-cola" readonly>${pixCopiaCola}</textarea>
                        <button class="btn btn-success btn-sm mt-2" id="copiar-pix">Copiar Pix</button>
                        <p class="mt-3">QR Code:</p>
                        <img src="${qrcode}" class="img-fluid" alt="QR Code">
                    `;
                    $('#pagamento-modal').modal('show');

                    // Adicionar evento de clique ao botão de copiar Pix
                    document.getElementById('copiar-pix').addEventListener('click', copiarPix);
                });
            });
        });
    </script>
</body>
</html>

