import requests
import json
import logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Suprimindo o aviso de requisição HTTPS não verificada
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Configurando o logging
logging.basicConfig(level=logging.DEBUG)

# Carregar dados de configuração a partir do arquivo config.json
with open('config.json', 'r') as config_file:
    config = json.load(config_file)

token_url = config["token_url"]
client_id = config["client_id"]
client_secret = config["client_secret"]
crt = config["crt"]
key = config["key"]
chave_pix = config["chave_pix"]
webhook_url = config["webhook_url"]

# Headers e payload para a requisição de token
headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
}

payload = {
    'grant_type': 'client_credentials',
    'client_id': client_id,
    'client_secret': client_secret,
}

try:
    # Fazendo a requisição para obter o token
    response = requests.post(
        token_url+"oauth/token",
        headers=headers,
        data=payload,
        cert=(crt, key),
        verify=False  # Desativa a verificação SSL
    )

    # Verificando a resposta
    if response.status_code in [200, 201]:
        token_data = response.json()
        access_token = token_data.get('access_token')
        logging.debug("Access Token: {}".format(access_token))

        # URL do webhook
        webhook_api_url = token_url+"webhook/{}".format(chave_pix)

        # Payload do webhook
        webhook_payload = {
            "webhookUrl": webhook_url
        }

        # Headers para a requisição do webhook
        webhook_headers = {
            'Authorization': 'Bearer {}'.format(access_token),
            'Content-Type': 'application/json'
        }

        # Fazendo a requisição PUT para configurar o webhook
        webhook_response = requests.put(
            webhook_api_url,
            headers=webhook_headers,
            data=json.dumps(webhook_payload),
            cert=(crt, key),
            verify=False  # Desativa a verificação SSL
        )

        # Verificando a resposta da configuração do webhook
        if webhook_response.status_code in [200, 201]:
            logging.debug("Webhook configurado com sucesso: {}".format(webhook_response.json()))
            print("Webhook configurado com sucesso.")
        else:
            logging.error("Erro ao configurar webhook: {} - {}".format(webhook_response.status_code, webhook_response.text))
            print("Erro ao configurar webhook: {} - {}".format(webhook_response.status_code, webhook_response.text))
    else:
        logging.error("Falha ao obter token: {} - {}".format(response.status_code, response.text))
        print("Falha ao obter token: {} - {}".format(response.status_code, response.text))
except requests.exceptions.RequestException as e:
    logging.error("Ocorreu um erro: {}".format(e))
    print("Ocorreu um erro: {}".format(e))

